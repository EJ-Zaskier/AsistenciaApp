"use client"

import { useEffect, useState } from "react"
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from "react-native"
import { MaterialIcons, Ionicons } from "@expo/vector-icons"
import { router } from "expo-router"
import AsyncStorage from "@react-native-async-storage/async-storage"

interface Subject {
  _id: string
  nombre: string
  grado: string
  id_carrera: string
  alumnos: User[]
}

interface User {
  _id: string
  nombre_completo: string
  matricula: string
  grupo: string
  carrera: string
}

export default function AttendanceScreen() {
  const [user, setUser] = useState<User | null>(null)
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [selectedTab, setSelectedTab] = useState("attendance")

  useEffect(() => {
    fetchUserData()
  }, [])

  const fetchUserData = async () => {
    try {
      const userData = await AsyncStorage.getItem("user")
      console.log("User data from AsyncStorage:", userData)
      if (userData) {
        const parsedUser = JSON.parse(userData)
        console.log("Parsed user data:", parsedUser)
        setUser(parsedUser)
        fetchSubjects(parsedUser._id)
      } else {
        console.log("No user data found in AsyncStorage")
      }
    } catch (error) {
      console.error("Error fetching user data:", error)
    }
  }

  const fetchSubjects = async (userId: string) => {
    try {
      console.log("Fetching subjects for user ID:", userId)
      const response = await fetch(`http://192.168.56.1:5000/api/materias/alumno/${userId}`)
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      const data = await response.json()
      console.log("Subjects data received:", JSON.stringify(data, null, 2))
      setSubjects(data)
    } catch (error) {
      console.error("Error fetching subjects:", error)
    }
  }

  const handleJustify = () => {
    router.push("/justificar")
  }

  const handleNotifications = () => {
    router.push("/notificaciones")
  }

  const WeekCalendar = () => {
    const [weekOffset, setWeekOffset] = useState(0)

    const getWeekDays = () => {
      const today = new Date()
      const firstDay = new Date(today)
      firstDay.setDate(today.getDate() - today.getDay() + weekOffset * 7)
      const days = []
      for (let i = 0; i < 7; i++) {
        const currentDate = new Date(firstDay)
        currentDate.setDate(firstDay.getDate() + i)
        days.push(currentDate)
      }
      return days
    }

    const monthNames = [
      "Enero",
      "Febrero",
      "Marzo",
      "Abril",
      "Mayo",
      "Junio",
      "Julio",
      "Agosto",
      "Septiembre",
      "Octubre",
      "Noviembre",
      "Diciembre",
    ]

    const weekDays = getWeekDays()
    const currentMonthName = monthNames[weekDays[0].getMonth()]
    const weekDayLabels = ["D", "L", "M", "M", "J", "V", "S"]

    return (
      <View style={styles.weekCalendarContainer}>
        <Text style={styles.monthText}>{currentMonthName}</Text>
        <View style={styles.calendarHeader}>
          <TouchableOpacity onPress={() => setWeekOffset((prev) => prev - 1)} style={styles.arrowButton}>
            <MaterialIcons name="chevron-left" size={24} color="#b6cce4" />
          </TouchableOpacity>

          <View style={styles.daysContainer}>
            {weekDayLabels.map((label, index) => (
              <View key={`header-${index}`} style={styles.dayLabelContainer}>
                <Text style={styles.dayLabel}>{label}</Text>
              </View>
            ))}

            {weekDays.map((date, index) => (
              <View key={index} style={styles.dayContainer}>
                <Text style={styles.dayNumber}>{date.getDate()}</Text>
              </View>
            ))}
          </View>

          <TouchableOpacity onPress={() => setWeekOffset((prev) => prev + 1)} style={styles.arrowButton}>
            <MaterialIcons name="chevron-right" size={24} color="#b6cce4" />
          </TouchableOpacity>
        </View>
      </View>
    )
  }

  console.log("Rendering AttendanceScreen. Subjects:", subjects)

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.justifyButton} onPress={handleJustify}>
          <MaterialIcons name="note-add" size={20} color="white" />
          <Text style={styles.justifyText}>Justificar</Text>
        </TouchableOpacity>

        <Text style={styles.titleText}>Asistencias</Text>

        <TouchableOpacity style={styles.profileButton}>
          <Text style={styles.userName}>{user?.nombre_completo || "Usuario"}</Text>
        </TouchableOpacity>
      </View>

      {/* Contenido Principal */}
      <ScrollView style={styles.content}>
        {subjects.length > 0 ? (
          subjects.map((subject, index) => (
            <View key={index} style={styles.subjectCard}>
              <View style={styles.subjectHeader}>
                <Text style={styles.subjectName}>{subject.nombre}</Text>
              </View>

              <Text style={styles.scheduleText}>{`Grado: ${subject.grado}`}</Text>
              <WeekCalendar />
            </View>
          ))
        ) : (
          <Text style={styles.noSubjectsText}>No hay materias disponibles</Text>
        )}
      </ScrollView>

      {/* Barra de navegación inferior */}
      <View style={styles.bottomNav}>
        <TouchableOpacity
          style={[styles.navButton, selectedTab === "attendance" && styles.navButtonActive]}
          onPress={() => setSelectedTab("attendance")}
        >
          <MaterialIcons name="assessment" size={24} color={selectedTab === "attendance" ? "#b6cce4" : "#fff"} />
          <Text style={[styles.navText, selectedTab === "attendance" && styles.navTextActive]}>Estadísticas</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.navButton} onPress={handleNotifications}>
          <Ionicons name="notifications" size={24} color="#fff" />
          <Text style={styles.navText}>Notificaciones</Text>
        </TouchableOpacity>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#7697a0",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 16,
    paddingTop: 48,
    backgroundColor: "#7697a0",
  },
  titleText: {
    fontSize: 20,
    color: "white",
    textAlign: "center",
    fontFamily: "Montserrat",
  },
  justifyButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#b6cce4",
    padding: 8,
    borderRadius: 20,
  },
  justifyText: {
    marginLeft: 4,
    color: "white",
    fontFamily: "Montserrat",
  },
  profileButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#b6cce4",
    padding: 8,
    borderRadius: 20,
  },
  userName: {
    color: "white",
    fontFamily: "Montserrat",
  },
  content: {
    flex: 1,
    padding: 16,
  },
  subjectCard: {
    backgroundColor: "white",
    borderRadius: 15,
    padding: 16,
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  subjectHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  subjectName: {
    fontSize: 18,
    color: "#2c3e50",
    fontFamily: "Montserrat",
  },
  scheduleText: {
    color: "#666",
    marginBottom: 12,
    fontFamily: "Montserrat",
  },
  weekCalendarContainer: {
    marginTop: 8,
  },
  monthText: {
    fontSize: 16,
    color: "#2c3e50",
    textAlign: "center",
    marginBottom: 8,
    fontFamily: "Montserrat",
  },
  calendarHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 8,
  },
  arrowButton: {
    padding: 8,
  },
  daysContainer: {
    flex: 1,
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-around",
    paddingHorizontal: 8,
  },
  dayLabelContainer: {
    width: "14.28%",
    alignItems: "center",
    marginBottom: 4,
  },
  dayLabel: {
    fontSize: 12,
    color: "#666",
    fontFamily: "Montserrat",
  },
  dayContainer: {
    width: "14.28%",
    height: 30,
    alignItems: "center",
    justifyContent: "center",
  },
  dayNumber: {
    fontSize: 12,
    color: "#2c3e50",
    fontFamily: "Montserrat",
  },
  bottomNav: {
    flexDirection: "row",
    backgroundColor: "#5f7d85",
    padding: 10,
    justifyContent: "space-around",
  },
  navButton: {
    alignItems: "center",
    padding: 10,
  },
  navButtonActive: {
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: 10,
  },
  navText: {
    color: "#fff",
    marginTop: 4,
    fontSize: 12,
    fontFamily: "Montserrat",
  },
  navTextActive: {
    color: "#b6cce4",
    fontFamily: "Montserrat",
  },
  noSubjectsText: {
    fontSize: 16,
    color: "white",
    textAlign: "center",
    marginTop: 20,
    fontFamily: "Montserrat",
  },
})

