"use client"

import { useEffect, useState, useCallback } from "react"
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from "react-native"
import { FontAwesome, MaterialIcons, Ionicons } from "@expo/vector-icons"
import { router, useLocalSearchParams } from "expo-router"

type AttendanceType = "asistencia" | "falta" | "justificada" | "retardo"

interface Alumno {
  _id: string
  nombre_completo: string
  matricula: string
  grupo: string
  carrera: string
}

interface Asistencia {
  _id: string
  fecha: string
  estado: AttendanceType
  id_salon: string
  id_horario: string
  id_alumno: string
}

interface Group {
  _id: string
  nombre: string
  descripcion: string
  id_carrera: string
}

interface Carrera {
  _id: string
  nombre: string
}

export default function GroupDetailScreen() {
  const { groupId } = useLocalSearchParams<{ groupId: string }>()
  const [group, setGroup] = useState<Group | null>(null)
  const [carrera, setCarrera] = useState<Carrera | null>(null)
  const [alumnos, setAlumnos] = useState<Alumno[]>([])
  const [attendances, setAttendances] = useState<{ [key: string]: Asistencia[] }>({})
  const [currentDate, setCurrentDate] = useState(new Date())
  const [error, setError] = useState<string | null>(null)

  const fetchGroupDetails = useCallback(async () => {
    try {
      const response = await fetch(`http://192.168.56.1:5000/api/grupos?${groupId}`)
      if (!response.ok) {
        const text = await response.text()
        throw new Error(`HTTP error! status: ${response.status}, body: ${text}`)
      }
      const data = await response.json()
      console.log("Group details:", JSON.stringify(data, null, 2))
      setGroup(data)
      fetchCarrera(data.id_carrera)
    } catch (error) {
      console.error("Error fetching group details:", error)
      setError(`Error fetching group details: ${error}`)
    }
  }, [groupId])

  const fetchCarrera = useCallback(async (carreraId: string) => {
    try {
      const response = await fetch(`http://192.168.56.1:5000/api/carrera?${carreraId}`)
      if (!response.ok) {
        const text = await response.text()
        throw new Error(`HTTP error! status: ${response.status}, body: ${text}`)
      }
      const data = await response.json()
      console.log("Carrera details:", JSON.stringify(data, null, 2))
      setCarrera(data)
    } catch (error) {
      console.error("Error fetching carrera:", error)
      setError(`Error fetching carrera: ${error}`)
    }
  }, [])

  const fetchAlumnos = useCallback(async () => {
    try {
      const response = await fetch(`http://192.168.56.1:5000/api/alumnos?grupo=${groupId}`)
      if (!response.ok) {
        const text = await response.text()
        throw new Error(`HTTP error! status: ${response.status}, body: ${text}`)
      }
      const data = await response.json()
      console.log("Alumnos:", JSON.stringify(data, null, 2))
      setAlumnos(data)
    } catch (error) {
      console.error("Error fetching alumnos:", error)
      setError(`Error fetching alumnos: ${error}`)
    }
  }, [groupId])

  const fetchAttendances = useCallback(async () => {
    try {
      const response = await fetch(`http://192.168.56.1:5000/api/Asistencia?grupo=${groupId}`)
      if (!response.ok) {
        const text = await response.text()
        throw new Error(`HTTP error! status: ${response.status}, body: ${text}`)
      }
      const data = await response.json()
      console.log("Asistencias:", JSON.stringify(data, null, 2))
      const attendancesByStudent: { [key: string]: Asistencia[] } = {}
      data.forEach((attendance: Asistencia) => {
        if (!attendancesByStudent[attendance.id_alumno]) {
          attendancesByStudent[attendance.id_alumno] = []
        }
        attendancesByStudent[attendance.id_alumno].push(attendance)
      })
      setAttendances(attendancesByStudent)
    } catch (error) {
      console.error("Error fetching attendances:", error)
      setError(`Error fetching attendances: ${error}`)
    }
  }, [groupId])

  useEffect(() => {
    fetchGroupDetails()
    fetchAlumnos()
    fetchAttendances()
  }, [fetchGroupDetails, fetchAlumnos, fetchAttendances])

  const handleBack = () => {
    router.back()
  }

  const getAttendanceColor = (percentage: number) => {
    if (percentage >= 90) return "#4CAF50"
    if (percentage >= 80) return "#8BC34A"
    if (percentage >= 70) return "#FFC107"
    if (percentage >= 60) return "#FF9800"
    return "#F44336"
  }

  const getAttendanceIcon = (type: AttendanceType) => {
    switch (type) {
      case "asistencia":
        return <MaterialIcons name="check-circle" size={20} color="#4CAF50" />
      case "falta":
        return <MaterialIcons name="cancel" size={20} color="#F44336" />
      case "justificada":
        return <Text style={styles.justifiedText}>J</Text>
      case "retardo":
        return <Text style={styles.lateText}>R</Text>
    }
  }

  const handlePrevWeek = () => {
    setCurrentDate(new Date(currentDate.getTime() - 7 * 24 * 60 * 60 * 1000))
  }

  const handleNextWeek = () => {
    setCurrentDate(new Date(currentDate.getTime() + 7 * 24 * 60 * 60 * 1000))
  }

  const calculateAttendancePercentage = (studentId: string) => {
    const studentAttendances = attendances[studentId] || []
    if (studentAttendances.length === 0) return 0
    const presentCount = studentAttendances.filter((a) => a.estado === "asistencia" || a.estado === "retardo").length
    return Math.round((presentCount / studentAttendances.length) * 100)
  }

  const weekDates = Array.from({ length: 5 }, (_, i) => {
    const date = new Date(currentDate)
    date.setDate(currentDate.getDate() - currentDate.getDay() + i + 1)
    return date
  })

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBack} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="white" />
        </TouchableOpacity>
        <View style={styles.titleContainer}>
          <Text style={styles.titleText}>{group?.nombre}</Text>
          <Text style={styles.subtitleText}>{group?.descripcion}</Text>
        </View>
      </View>

      {/* Contenido Principal */}
      <ScrollView style={styles.content}>
        {error ? (
          <Text style={styles.errorText}>{error}</Text>
        ) : (
          <View style={styles.groupCard}>
            <Text style={styles.careerText}>Carrera: {carrera?.nombre || "Cargando..."}</Text>

            <View style={styles.attendanceContainer}>
              <View style={styles.calendarContainer}>
                <View style={styles.monthContainer}>
                  <TouchableOpacity onPress={handlePrevWeek} style={styles.arrowButton}>
                    <FontAwesome name="chevron-left" size={14} color="#2c3e50" />
                  </TouchableOpacity>
                  <Text style={styles.monthText}>
                    {currentDate.toLocaleString("default", { month: "long", year: "numeric" })}
                  </Text>
                  <TouchableOpacity onPress={handleNextWeek} style={styles.arrowButton}>
                    <FontAwesome name="chevron-right" size={14} color="#2c3e50" />
                  </TouchableOpacity>
                </View>
                <View style={styles.daysContainer}>
                  {weekDates.map((date, index) => (
                    <View key={index} style={styles.dayItem}>
                      <Text style={styles.dayName}>
                        {date.toLocaleString("default", { weekday: "short" }).charAt(0)}
                      </Text>
                      <Text style={styles.dayText}>{date.getDate()}</Text>
                    </View>
                  ))}
                </View>
              </View>

              <View style={styles.studentsContainer}>
                {alumnos.map((alumno) => {
                  const attendancePercentage = calculateAttendancePercentage(alumno._id)
                  return (
                    <View key={alumno._id} style={styles.studentRow}>
                      <View style={styles.studentNameContainer}>
                        <Text style={styles.studentName}>{alumno.nombre_completo}</Text>
                      </View>
                      <View style={styles.attendanceInfo}>
                        {weekDates.map((date, index) => {
                          const attendance = attendances[alumno._id]?.find(
                            (a) => new Date(a.fecha).toDateString() === date.toDateString(),
                          )
                          return (
                            <View key={index} style={styles.attendanceIcon}>
                              {attendance ? (
                                getAttendanceIcon(attendance.estado)
                              ) : (
                                <Text style={styles.noDataText}>-</Text>
                              )}
                            </View>
                          )
                        })}
                        <View
                          style={[
                            styles.attendancePercentage,
                            { backgroundColor: getAttendanceColor(attendancePercentage) },
                          ]}
                        >
                          <Text style={styles.percentageText}>{`${attendancePercentage}%`}</Text>
                        </View>
                      </View>
                    </View>
                  )
                })}
              </View>
            </View>
          </View>
        )}
      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#7697a0",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    paddingTop: 48,
    backgroundColor: "#7697a0",
  },
  backButton: {
    marginRight: 16,
  },
  titleContainer: {
    flex: 1,
  },
  titleText: {
    fontSize: 20,
    color: "white",
    fontFamily: "Montserrat",
  },
  subtitleText: {
    fontSize: 14,
    color: "white",
    fontFamily: "Montserrat",
    opacity: 0.8,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  loadingText: {
    color: "white",
    fontSize: 16,
    textAlign: "center",
    marginTop: 20,
  },
  groupCard: {
    backgroundColor: "white",
    borderRadius: 15,
    padding: 16,
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  careerText: {
    fontSize: 16,
    color: "#2c3e50",
    fontFamily: "Montserrat",
    marginBottom: 16,
  },
  attendanceContainer: {
    alignItems: "center",
  },
  calendarContainer: {
    backgroundColor: "#f0f0f0",
    borderRadius: 10,
    padding: 8,
    width: "100%",
    marginBottom: 16,
  },
  monthContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  monthText: {
    fontSize: 14,
    color: "#2c3e50",
    fontWeight: "bold",
    fontFamily: "Montserrat",
  },
  arrowButton: {
    padding: 4,
  },
  daysContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "60%",
    paddingHorizontal: 8,
    marginLeft: "40%",
  },
  dayItem: {
    alignItems: "center",
    width: 32,
    marginHorizontal: 4,
  },
  dayName: {
    fontSize: 12,
    color: "#7f8c8d",
    marginBottom: 4,
  },
  dayText: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#2c3e50",
  },
  studentsContainer: {
    width: "100%",
  },
  studentRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#eee",
  },
  studentNameContainer: {
    width: "40%",
  },
  studentName: {
    fontSize: 14,
    color: "#2c3e50",
    fontFamily: "Montserrat",
  },
  attendanceInfo: {
    flexDirection: "row",
    alignItems: "center",
    width: "60%",
    justifyContent: "space-evenly",
  },
  attendanceIcon: {
    width: 32,
    alignItems: "center",
    justifyContent: "center",
  },
  attendancePercentage: {
    padding: 6,
    borderRadius: 12,
    minWidth: 50,
    alignItems: "center",
  },
  percentageText: {
    color: "white",
    fontSize: 12,
    fontFamily: "Montserrat",
  },
  justifiedText: {
    color: "#FF9800",
    fontSize: 14,
    fontWeight: "bold",
    fontFamily: "Montserrat",
  },
  lateText: {
    color: "#FFC107",
    fontSize: 14,
    fontWeight: "bold",
    fontFamily: "Montserrat",
  },
  noDataText: {
    color: "#bbb",
    fontSize: 14,
    fontFamily: "Montserrat",
  },
  errorText: {
    color: "red",
    fontSize: 16,
    textAlign: "center",
    marginTop: 20,
  },
})

